# Obligatorisk oppgave 3 i Algoritmer og Datastrukturer

Denne oppgaven er en innlevering i Algoritmer og Datastrukturer. 
Oppgaven er levert av følgende student:
Nabila Abdirashid Mohamed s364588@oslomet.no

Jeg endret retningen på noden pekte ved å bruke programkode 5.2.3a fra programmet i oppgave 1.

Øvelse 2 innebar en while-løkke som løper kontinuerlig så lenge variabelen p ikke er lik null. 
Hver gang cmp sammenligner verdier, økte variabeltallet med 1. Hvis cmp < 0,
endret utførelsesretningen seg og fortsatte til p nådde toppen av treet. 
Hvis cmp > 0, kjørte programmet i den retningen og fortsatte til p nådde bunnen av treet.

Jeg brukte en programkode fra kompendiet for å lage oppgave 3-oppgaven min,
men jeg endret den slik at den ikke opprettet en node i metoden. 
Deretter brukte jeg binære treregler for å brainstorme ideer før jeg opprettet oppgaven min.
Oppgaven min brukte deretter den endrede programkoden for å lage en løsning.

While-løkken jeg programmerte får rotverdien til å øke til den blir null, som er utenfor treet. 
Jeg utførte denne oppgaven ved å starte med den første oppføringsrekkefølgen, 
og deretter skrive en løkke som utfører oppgaven.